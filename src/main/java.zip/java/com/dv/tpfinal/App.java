/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.dv.tpfinal;

import com.dv.tpfinal.controllers.GarageController;
import com.dv.tpfinal.sys.DB;
import com.dv.tpfinal.menu.MainMenu;

/**
 *
 * @author nico
 */
public class App {
    public static void main(String[] args) {    
        DB db = DB.getInstance();
        db.init();
        
        GarageController garage = GarageController.getInstance(4, 1231.20);
        garage.addAuto(250000, "Toyota", 4);
        garage.addAuto(60000, "Ford", 3);
        garage.addMoto(30000, "Kawasaki", 50);
        
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        //db.close();
    }
}
